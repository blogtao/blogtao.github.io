---
title: About Me
date: 2016-03-20 20:00:00
---
## 关于我
郭海涛，一位90后小猿，有事请<a 
href="mailto:guohaitao90@126.com" target="_blank" rel="external">联系我。</a>
## iOS专业技能
1、熟练使用Mac OS、iOS开发、测试和优化工具，熟悉iOS平台框架原理。2、熟练掌握C、Objective-C，了解Swift。熟悉Cocoa、UIKit和Foundation框架。3、熟练掌握内存管理原理、MRC和ARC混编。4、熟悉网络通信原理，熟悉HTTP、TCP/IP协议、Socket网络编程。5、熟悉iOS多线程编程，熟练掌握NSThread、NSOperation和GCD。6、熟悉掌握StoryBoard和xib、AutoLayout自动布局和屏幕适配。7、熟练掌握MVC、单例、KVO等常用设计模式，了解面向对象编程思想。8、熟悉网络解析协议，熟练掌握JSON和XML解析。9、熟练掌握XMPP协议、熟悉即时通讯。10、熟悉SQL语句，熟悉SQLite数据库编程，熟练使用CoreData。11、熟悉数据持久化存储，熟练使用NSUserDefaults、plist文件和归档。12、熟悉常用数据结构和算法，有良好的代码风格与软件设计能力。13、熟悉多媒体控件，熟练掌握视频播放、拍照开发流程。14、熟练掌握系统MapKit定位，熟练使用其他第三方地图SDK。15、熟练使用AFNetWorking、SDWebImage、JSONModel等第三方类库。16、熟练使用友盟分享和登录、极光推送。17、能够按照支付宝、微信和其他第三方开发文档完成支付流程。18、熟练使用Git，对SVN有一定了解。19、熟练掌握CocoaPods第三方管理工具。20、熟练掌握iOS产品上线流程、证书配置、具有独立开发和团队开发的能力。21、有良好的英语阅读能力、较强的独立解决问题和学习的能力。其他：对HTML、XML、CSS、JavaScript、PHP、Java编程有一定基础
## 2017 国家法定节假日
![2017国家法定节假日](../images/AboutMe/2017Vacation.png)
## 2017 日历
![2016日历](../images/AboutMe/2017.png)
<!--<img src="../images/AboutMe/2017.png" width=80% height=80% />-->

### 名言警句
> 子曰：“君子有三戒：少之时，血气未定，戒之在色；及其壮也，血气方刚，戒之在斗；及其老也，血气既衰，戒之在得。”---《论语·季氏》

孔子说：“君子有三种事情应引以为戒：年少的时候，血气还不成熟，要戒除对万事万物的诱惑；等到身体成熟了，血气方刚，要戒除与人争斗；等到老年，血气已经衰弱了，要戒除贪得无厌。”
